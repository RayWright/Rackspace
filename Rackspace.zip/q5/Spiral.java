package spiral;

public class Spiral 
{
    public static void main(String[] args) 
    {
        int[][] values = {{1,2,3}, {4,5,6}, {7,8,9}};
      
        int startX = 0, startY = 0, endX = values[0].length - 1, endY = values.length - 1, i;
           
        while(endX - startX >= 0 && endY - startY >= 0)
        {
            for(i = startX; i <= endX; i++)
            {
                System.out.print(values[startY][i]);
            }
            
            for(i = startY + 1; i <= endY; i++)
            {
                System.out.print(values[i][endX]);
            }
            
            for(i = endX - 1; i >= startX; i--)
            {
                System.out.print(values[endY][i]);
            }
            
            for(i = endY - 1; i >= startY + 1; i--)
            {
                System.out.print(values[i][startX]);
            }
            
            startX++;
            startY++;
            endX--;
            endY--;
        }
        System.out.println();
    }
}
