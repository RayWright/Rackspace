package justifytext;

import java.util.ArrayList;
import java.util.List;

public class JustifyText 
{
    public static void main(String[] args) 
    {
        int colWidth = 20;
        String line;
        String text = "The quick brown fox jumps over the lazy dog";
        
        String[] words = text.split(" ");
        
        List<String> colLines = new ArrayList<>();
        
        int numberOfLines = text.length()/colWidth;
        
        if(text.length() % colWidth > 0)
        {
            numberOfLines++;
        }
        
        int wordIndex = 0;
        
        for(int index = 0; index < numberOfLines; index++)
        {
            line = words[wordIndex++] + " ";
            
            while(line.length() < colWidth && wordIndex < words.length)
            {
                if(line.length() + words[wordIndex].length() < colWidth)
                {
                    line += words[wordIndex++] + " ";
                }
            }
            
            line = line.trim();
            
            int pos1;
            int pos2;
            int spacesNeeded = colWidth - line.length();
            int spaceIndex1 = 0;
            int spaceIndex2 = line.length();
            
            do
            {
                pos1 = line.indexOf(" ", spaceIndex1);
                pos2 = line.lastIndexOf(" ", spaceIndex2);
                
                if(pos1 < pos2)
                {
                    spaceIndex1 = pos1 + 1;
                    spaceIndex2 = pos2 - 1;
                
                }            
            } while(pos1 < pos2);
            
            for(int index1 = 0; index1 < spacesNeeded; index1++)
            {
                if(pos1 != -1 && pos2 != -1)
                {
                    String line1 = line.substring(0, pos1 + 1);
                    String line2 = line.substring(pos1 + 1, line.length());
                    
                    line = line1 + " " + line2;
                    System.out.printf("line is %s and length is %d\n", line, line.length());
                }
            }
            
            colLines.add(line);
        }
        
        for(String colLine : colLines)
        {
            System.out.println(colLine);
        }
    }
}
