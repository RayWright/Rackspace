package stringmanipulation;

public class StringManipulation 
{
    public static void main(String[] args) 
    {
        StringBuilder testStr = new StringBuilder("abb cddpddef gh");
        char currentChar = ' ';
        
        for(int index = testStr.length() - 1 ; index > 0; index--)
        {
            if(testStr.charAt(index) == ' ' || currentChar == testStr.charAt(index))
            {
                testStr.deleteCharAt(index);
            }
            else
            {
                currentChar = testStr.charAt(index);
            }
        }
        
        System.out.println(testStr.toString());
    } 
}
