-module(hello).
-export([callme/0]).

callme() -> io:format("Hello World ~n").